create table Usuario(
Email varchar(50) not null primary key,
nome varchar(50)not null,
senha varchar(50))
